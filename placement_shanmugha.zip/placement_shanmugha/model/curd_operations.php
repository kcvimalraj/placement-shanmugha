<?php 

	include_once 'insert.php';
	include_once 'delete.php';
	include_once 'select.php';
	include_once 'update.php';