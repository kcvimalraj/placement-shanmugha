<?php 
  include_once 'headers.php';
 ?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
</head>
<body>
  <body background="bg1.jpg"> <br>
    <div class="container">
      <table style="width:100%">
        <tr>
         <td><img style="width: 130px;height:130x;" src="s.png" ></td>
         <td><h1 style="text-align: center; color: #ffd681; font-family: Copperplate Gothic Bold; font-size: 42px;">Sri Shanmugha College of Engineering and Technology               
         </h1><h1 style="margin-left: 330px; color: #ffd681; font-family: Copperplate Gothic Bold; font-size: 42px;">sankari</h1> </td><br>
         <tr>
      </table> <br>
    <div>                 
      <h1 style="margin-left: 860px; font-family: Buxton Sketch; color: #f9ffff">LOGIN</h1>     </div>
    </div><br><br>
  <div><br>
    <form style="text-align: center;" method="POST" action="../view/add_remainder.php">
            <div class="input-group">
               <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
          <input id="email" type="text" class="form-control" name="email" placeholder="Email">
        </div><br>
         <div class="input-group">
          <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
          <input id="password" type="password" class="form-control" name="password" placeholder="Password">
          </div><br>
      <button class="btn btn-info" form-control>Login</button>
      </form>
      </form></div>
<div style="text-align: right;">

<a href="signup.php"> Need an account?</a>

</div>
</div>
</body>
</tr></tr></table></div></body></body></html>
<?php 
?>