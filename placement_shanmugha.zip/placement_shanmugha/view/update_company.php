<?php 


	include_once 'header.php';
	include_once '../controller/view_companies.php'; 
	$id = $_GET['id'];
	$condition = "`Id` = $id";
	$raw_data = update_data($condition);

	$update_data = $raw_data[0];
	echo "<pre>";
	print_r($update_data);
	echo "</pre>";


?>
	
	<div>
		<form method="POST" action="../controller/update_company.php">
			<input type="text" name="Company_Name" placeholder="Company_Name" class="form-control" value="<?php echo $update_data['Company_Name']; ?>" required><br>
			<textarea name="Company_Address" placeholder="Company_Address" class="form-control" rows="5" ><?php echo $update_data['Company_Address']; ?></textarea><br>
			<input type="text" name="Domain" placeholder="Domain" class="form-control" value="<?php echo $update_data['Domain']; ?>" required><br>
			<textarea name="Requirements" placeholder="Company Requirements" class="form-control" rows="5" ><?php echo $update_data['Requirements']; ?></textarea><br>
			<input type="number" name="Mobile_Number" placeholder="Mobile_Number" value="<?php echo $update_data['Mobile_Number']; ?>" class="form-control" required><br>
			<input type="date" name="company_visited_day" value="<?php echo $update_data['company_visited_day']; ?>" class="form-control" required><br>
			<input type="date" name="remaind_me_on" placeholder="Remaind Me on" value="<?php echo $update_data['remaind_me_on']; ?>" class="form-control" required><br>
			<input type="submit" class="btn btn-primary form-control" value="Update Remainder">
		</form>
	</div>



<?php include_once 'footer.php'; ?>