<?php 
include_once 'header.php';
?>
	<div>
	<form>
		<a href="student_details.php"><b>Student Details</b></a></br>
	</form>
	</div>
	<div>
	<form>
		<a href="company_details.php"><b>Company Details</b></a></br>
		</form>
	</div>
	<!--<div>
		<form method="POST" action="../controller/add_remainder.php">
			<input type="text" name="company_name" placeholder="company_name" class="form-control" required>
			<textarea name="company_address" placeholder="Company Address" class="form-control" rows="5" ></textarea>
			<input type="date" name="company_visited_day" class="form-control" required>
			<textarea name="company_requirements" placeholder="Company Requirements" class="form-control" rows="5" ></textarea>
			<input type="number" name="remaind_me_on" placeholder="Remaind Me on" class="form-control" required>
		</form>
	</div>-->
<?php
include_once 'footer.php';

 ?>