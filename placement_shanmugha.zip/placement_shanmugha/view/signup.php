<?php
include_once 'headers.php';

?> 
<br>
<div class="container">
<?php
if(isset($_GET['status']))
{
switch ($_GET['status'])
 {
	case 'user_exist':
		echo "<div class='alert alert-warning'>user already exists</div>";

		break;
	case 'incorrect_password':
	echo "<div class='alert alert-warning'>please check ur re type password</div>";
		break;
}
}
?>
<body background="bg1.jpg"> <br>
    
    
    <div class="container">
    <table style="width:100%">
		<tr>
		<td><img style="width: 130px;height:130px;" src="s.png" ></td>
		<td><h1 style="text-align: center; color: #ffd681; font-family: Copperplate Gothic Bold; font-size: 42px;">Sri Shanmugha College of Engineering and Technology               
		</h1><h1 style="margin-left: 330px; color: #ffd681; font-family: Copperplate Gothic Bold; font-size: 42px;">sankari</h1> </td><br>
<tr>
	</table>
	 <br>
	<div>                 
		<h1 style="margin-left: 850px; font-family: Buxton Sketch; color: #f9ffff"> SIGN UP</h1>     </div>
	</div><br><br>
	
 <form style="text-align: center;" method="POST" action="../view/add_remainder.php">
<div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
    <input id="email" type="text" class="form-control" name="email" placeholder="Email">
 </div><br>
   <div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
    <input id="password" type="password" class="form-control" name="password" placeholder="Password">
    </div><br>
    <div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
<input type="password" name="Re_enter_password" class="form-control" required placeholder="Re_enter_password"></div><br>

<button class="btn btn-info" form-control>SIGN UP</button>
</form>
<div style="text-align: right;">
<a href="login.php"> already having an account?</a>

</div>
<?php 
?>