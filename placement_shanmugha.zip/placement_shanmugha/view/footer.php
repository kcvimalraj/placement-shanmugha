  </section>
  </div>
  <!-- footer -->
  <footer class="main-footer">
   <strong>Copyright &copy; 2014-2016 <a href="http://vefetch.com">Vefetch</a>.</strong> All rights
    reserved.
  </footer>
</div>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/app.min.js"></script>
</body>
</html>
