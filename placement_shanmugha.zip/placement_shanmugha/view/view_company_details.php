<?php include_once 'header.php'; 
	include_once '../controller/view_companies.php';
	$selected_data = select_data();


?>
<table style="width: 100%">
	
	<tr>
		<th>Company Name</th>
		<th>Company Address</th>
		<th>Domain</th>
		<th>Requirements</th>
		<th>Mobile Number</th>
		<th>company visited day</th>
		<th>remaind me on</th>
		<th>Action</th>
	</tr>
	<?php foreach ($selected_data as $key => $value) {
		echo "<tr>";
		echo "<td>".$value['Company_Name']."</td>";
		echo "<td>".$value['Company_Address']."</td>";
		echo "<td>".$value['Domain']."</td>";
		echo "<td>".$value['Requirements']."</td>";
		echo "<td>".$value['Mobile_Number']."</td>";
		echo "<td>".$value['company_visited_day']."</td>";
		echo "<td>".$value['remaind_me_on']."</td>";
		echo "<td><a href='../controller/delete_company.php?id=".$value['Id']."' class='btn btn-danger'>Delete</a><a href='edit_company.php?id=".$value['Id']."' class='btn btn-warning'>Edit</a></td>";
		echo "</tr>";


	} ?>


</table>



	
<?php include_once 'footer.php'; ?>