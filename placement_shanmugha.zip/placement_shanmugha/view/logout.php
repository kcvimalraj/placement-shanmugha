<?php
// include_once '../../controllers/default_functions.php';
// log_out();
header('location: login.php');
