<?php 
include_once 'header.php';
?>
	
	<div>
		<form method="POST" action="../controller/add_remainder.php">
			<input type="text" name="Student_Name" placeholder="Student_Name" class="form-control" required><br>
			<input type="number" name="Age" placeholder="Age" class="form-control"><br>
			<input type="text" name="College" placeholder="College" class="form-control" required><br>
			<input type="number" name="CGPA" placeholder="CGPA" class="form-control" required><br>
			<textarea name="Address" placeholder="Address" class="form-control" required></textarea><br>
			<input type="number" name="Mobile_Number" placeholder="Mobile_Number" class="form-control" required><br>
			<input type="submit" class="btn btn-primary form-control" value="Add Remainder">
		</form>
	</div>
<?php
include_once 'footer.php';


 ?>