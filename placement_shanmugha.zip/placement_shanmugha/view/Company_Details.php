<?php 
include_once 'header.php';
?>
	
	<div>
		<form method="POST" action="../controller/add_remainder.php">
			<input type="text" name="Company_Name" placeholder="Company_Name" class="form-control" required><br>
			<textarea name="Company_Address" placeholder="Company_Address" class="form-control" rows="5" ></textarea><br>
			<input type="text" name="Domain" placeholder="Domain" class="form-control" required><br>
			<textarea name="Requirements" placeholder="Company Requirements" class="form-control" rows="5" ></textarea><br>
			<input type="number" name="Mobile_Number" placeholder="Mobile_Number" class="form-control" required><br>
			<input type="date" name="company_visited_day" class="form-control" required><br>
			<input type="date" name="remaind_me_on" placeholder="Remaind Me on" class="form-control" required><br>
			<input type="submit" class="btn btn-primary form-control" value="Add Remainder">
		</form>
	</div>
<?php
include_once 'footer.php';

 ?>