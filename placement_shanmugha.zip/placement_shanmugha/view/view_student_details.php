<?php include_once 'header.php'; 
	include_once '../controller/view_students.php';
	$selected_data = select_data();


?>
<table style="width: 100%">
	
	<tr>
		<th>Student_Name</th>
		<th>Age</th>
		<th>College	</th>
		<th>CGPA</th>
		<th>Address	</th>
		<th>Mobile_Number</th>
	</tr>
	<?php foreach ($selected_data as $key => $value) {
		echo "<tr>";
		echo "<td>".$value['Student_Name']."</td>";
		echo "<td>".$value['Age']."</td>";
		echo "<td>".$value['College']."</td>";
		echo "<td>".$value['CGPA']."</td>";
		echo "<td>".$value['Address']."</td>";
		echo "<td>".$value['Mobile_Number']."</td>";
		echo "<td><a href='../controller/delete_student.php?id=".$value['Id']."' class='btn btn-danger'>Delete</a><a href='edit_student.php?id=".$value['Id']."' class='btn btn-warning'>Edit</a></td>";
		echo "</tr>";


	} ?>


</table>



	
<?php include_once 'footer.php'; ?>