<?php 


	include_once 'header.php';
	include_once '../controller/view_students.php'; 
	$id = $_GET['id'];
	$condition = "`Id` = $id";
	$raw_data = select_data($condition);

	$select_data = $raw_data[0];
	

?>
	<div>
		<form method="POST" action="../controller/update_student.php">
		<input type="hidden" name="id" value="<?php echo $select_data['Id']; ?>"> 
			<input type="text" name="Student_Name" placeholder="Student_Name" class="form-control" value="<?php echo $select_data['Student_Name']; ?>" required><br>
			<input type="number" name="Age" placeholder="Age" class="form-control" value="<?php echo $select_data['Age']; ?>"><br>
			<input type="text" name="College" placeholder="College" class="form-control" value="<?php echo $select_data['College']; ?>" required><br>
			<input type="number" name="CGPA" placeholder="CGPA" class="form-control" value="<?php echo $select_data['CGPA']; ?>"> <br>
			<textarea name="Address" placeholder="Address" rows="5" class="form-control" required> <?php echo $select_data['Address'];  ?>  </textarea><br>
			<input type="number" name="Mobile_Number" placeholder="Mobile_Number" value="<?php echo $select_data['Mobile_Number']; ?>" class="form-control" required><br>
			<input type="submit" class="btn btn-primary form-control" value="Update Remainder">
	    </form> 
	</div>



<?php include_once 'footer.php'; ?>