<?php include_once 'header.php';

	add_user($_POST);
	function add_user($raw_values){
		
		
			$conn = db_connect();
			if(insert('company_details', $raw_values, $conn)){
				header('location: ../view/view_company_details.php?status=inserted');
			}
				
			$conn = db_connect();
			if(insert('student_details', $raw_values, $conn)){
				header('location: ../view/view_student_details.php?status=inserted');
		}

	}


 ?>