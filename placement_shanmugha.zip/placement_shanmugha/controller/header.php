<?php 
	include_once '../model/db.php';
	include_once 'common_functions.php';