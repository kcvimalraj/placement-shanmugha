<?php 

	
	include_once 'header.php';
	delete_data($_GET);
	function delete_data($condition){
		$conn = db_connect();
		if(delete('company_details',$condition,$conn)){
			header("location:../view/view_company_details.php?status=deleted");
		}else{
			header("location:../view/view_company_details.php?status=not_deleted");
		}
	}


 ?>