<?php  
	
	include_once 'header.php';

	function select_data($condition=""){
		$conn = db_connect();
		return select('*','company_details',$condition,$conn);
	}




?>