<?php 

header('location: view/add_remainder.php');